<html>
</head><title>Please login or register</title></head>

<body>

	<h1 style = "text-align:center">
		Please login or register first to pay for the course!<br>
		And if you have aleardy paid then just login and access the course
	
	</h1>


</body>

</html>