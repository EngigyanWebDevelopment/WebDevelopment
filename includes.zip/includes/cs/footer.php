<div class="container-fluid" id="footer">
        <div class="row" id="foot_row">
            <div class="col-lg-3 col-sm-4 col-6">
                <p id="foot_titles">EngiGyan</p>
                <ul style="list-style-type: none;" id="foot_ul">
                    <li><a href="../aboutus.php" id="foo">About Us</a></li>
                    <li><a href="" id="foo">News & Media</a></li>
                    <li><a href="" id="foo">Contact Us</a></li>
                    <li><a href="" id="foo">Blog</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-sm-4 col-6">
                <p id="foot_titles">WORK WITH US</p>
                <ul style="list-style-type: none;" id="foot_ul">
                    <li><a href="" id="foo">Careers</a></li>
                    <li><a href="" id="foo">Become an Instructor</a></li>
                    <li><a href="" id="foo">Become an Affiliate</a></li>
                    <li><a href="" id="foo">Hire from EngiGyan</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-sm-4 col-lg-3 col-6">
                <p id="foot_titles">USEFUL LINKS</p>
                <ul style="list-style-type: none;" id="foot_ul">
                    <li><a href="" id="foo">Reviews</a></li>
                    <li><a href="" id="foo">Terms & Conditions</a></li>
                    <li><a href="" id="foo">Privacy Policy</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-sm-4 col-lg-3 col-6">
                <p id="foot_titles">KEEP IN TOUCH</p>
                <ul style="list-style-type: none; overflow: hidden;" id="foot_ul">
                    <li class="ga-fb" style="float: left;"><a href="https://www.facebook.com/engigyan" target="_blank" class="fb" id="foo"><i class="fa fa-facebook-square"></i></a></li>
                    <li class="ga-instagram" style="float: left;"><a href="https://www.instagram.com/engigyan_live_online_training/" target="_blank" class="ins" id="foo"><i class="fa fa-instagram"></i></a></li>
                    <li class="ga-blogger" style="float: left;"><a href="http://www.engigyaneducation.blogspot.com/" target="_blank" class="blog" id="foo"><i class="fa fa-rss"></i></a></li>
                    <li class="ga-linkedin" style="float: left;"><a href="https://www.linkedin.com/in/engigyan/" target="_blank" class="in" id="foo"><i class="fa icon-fa-linkedin fa-linkedin"></i></a></li>
                    <li class="ga-youtube" style="float: left;"><a href="https://www.youtube.com/channel/UC-42kedUbInLAALSaKy7zTg" target="_blank" class="ut" id="foo"><i class="fa icon-fa-youtube fa-youtube-play"></i></a></li>
                </ul>
            </div>
        </div>
    </div>